
import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Calendar, 
  BookOpen, 
  MessageSquare, 
  Sparkles,
  Trophy,
  Brain,
  Moon,
  Sun
} from 'lucide-react';
import FlashScreen from './components/FlashScreen.tsx';
import Dashboard from './components/Dashboard.tsx';
import Planner from './components/Planner.tsx';
import AIPlanner from './components/AIPlanner.tsx';
import QuizView from './components/QuizView.tsx';
import IdeaGenerator from './components/IdeaGenerator.tsx';
import Chatbot from './components/Chatbot.tsx';
import Flashcards from './components/Flashcards.tsx';
import { Task, Flashcard, Quiz, UserStats, StudyLog } from './types.ts';

type View = 'dashboard' | 'planner' | 'ai-planner' | 'quiz' | 'ideas' | 'chatbot' | 'flashcards';
type Theme = 'light' | 'dark';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('study_theme');
    return (saved as Theme) || 'light';
  });
  
  // App-wide state
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('study_tasks');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [flashcards, setFlashcards] = useState<Flashcard[]>(() => {
    const saved = localStorage.getItem('study_flashcards');
    return saved ? JSON.parse(saved) : [];
  });

  const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
    const saved = localStorage.getItem('study_quizzes');
    return saved ? JSON.parse(saved) : [];
  });

  const [studyLogs, setStudyLogs] = useState<StudyLog[]>(() => {
    const saved = localStorage.getItem('study_logs');
    if (saved) return JSON.parse(saved);
    
    // Default 7 days of empty logs
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const today = new Date().getDay();
    const logs: StudyLog[] = [];
    for (let i = 6; i >= 0; i--) {
      const dayIdx = (today - i + 7) % 7;
      logs.push({
        date: days[dayIdx],
        hours: 0,
        tasksCompleted: 0
      });
    }
    return logs;
  });

  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('study_stats');
    return saved ? JSON.parse(saved) : {
      streak: 0,
      totalQuizzes: 0,
      totalStudyHours: 0,
      completedTopics: 0
    };
  });

  // Persistence
  useEffect(() => {
    localStorage.setItem('study_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('study_flashcards', JSON.stringify(flashcards));
  }, [flashcards]);

  useEffect(() => {
    localStorage.setItem('study_quizzes', JSON.stringify(quizzes));
  }, [quizzes]);

  useEffect(() => {
    localStorage.setItem('study_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem('study_logs', JSON.stringify(studyLogs));
  }, [studyLogs]);

  useEffect(() => {
    localStorage.setItem('study_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) return <FlashScreen theme={theme} />;

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const updateDailyLog = (hours: number, tasksInc: number) => {
    const newLogs = [...studyLogs];
    const todayLog = newLogs[newLogs.length - 1];
    todayLog.hours += hours;
    todayLog.tasksCompleted += tasksInc;
    setStudyLogs(newLogs);
    
    setStats(prev => ({
      ...prev,
      totalStudyHours: prev.totalStudyHours + hours,
      streak: prev.streak === 0 ? 1 : prev.streak // Simple streak start
    }));
  };

  const handleTaskToggle = (updatedTasks: Task[], taskId: string) => {
    const task = updatedTasks.find(t => t.id === taskId);
    if (task && task.completed) {
      // Logic: Completing a task adds 1 hour of "study time" to stats
      updateDailyLog(1, 1);
    }
    setTasks(updatedTasks);
  };

  const handleQuizComplete = (quiz: Quiz) => {
    setQuizzes([quiz, ...quizzes]);
    const isSuccess = quiz.score && quiz.total && (quiz.score / quiz.total) >= 0.8;
    setStats(prev => ({
      ...prev,
      totalQuizzes: prev.totalQuizzes + 1,
      completedTopics: isSuccess ? prev.completedTopics + 1 : prev.completedTopics,
      streak: prev.streak === 0 ? 1 : prev.streak
    }));
  };

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard stats={stats} tasks={tasks} quizzes={quizzes} theme={theme} studyLogs={studyLogs} />;
      case 'planner':
        return <Planner tasks={tasks} setTasks={(val) => {
          if (typeof val === 'function') {
            setTasks(prev => {
              const next = val(prev);
              // We need to track which task was toggled to update stats. 
              // Simplest is to let Planner component handle the callback or just watch tasks.
              return next;
            });
          } else {
            setTasks(val);
          }
        }} onTaskToggle={handleTaskToggle} />;
      case 'ai-planner':
        return <AIPlanner />;
      case 'quiz':
        return <QuizView onQuizComplete={handleQuizComplete} />;
      case 'ideas':
        return <IdeaGenerator />;
      case 'chatbot':
        return <Chatbot />;
      case 'flashcards':
        return <Flashcards cards={flashcards} setCards={setFlashcards} />;
      default:
        return <Dashboard stats={stats} tasks={tasks} quizzes={quizzes} theme={theme} studyLogs={studyLogs} />;
    }
  };

  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Home' },
    { id: 'planner', icon: Calendar, label: 'Planner' },
    { id: 'ai-planner', icon: Sparkles, label: 'AI Plan' },
    { id: 'quiz', icon: Brain, label: 'Quiz' },
    { id: 'flashcards', icon: BookOpen, label: 'Cards' },
    { id: 'chatbot', icon: MessageSquare, label: 'Chat' },
    { id: 'ideas', icon: Trophy, label: 'Ideas' },
  ];

  return (
    <div className={`flex flex-col h-screen max-w-lg mx-auto transition-colors duration-300 relative shadow-2xl ${
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
    }`}>
      {/* Header */}
      <header className={`p-4 border-b flex justify-between items-center sticky top-0 z-10 transition-colors ${
        theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-2">
          <div className="bg-indigo-600 p-1.5 rounded-lg">
            <BookOpen className="text-white w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold">StudyMate</h1>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={toggleTheme}
            className={`p-2 rounded-full transition-colors ${
              theme === 'dark' ? 'bg-slate-800 text-amber-400' : 'bg-slate-100 text-slate-500'
            }`}
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <div className="flex items-center bg-orange-100 dark:bg-orange-900/30 px-3 py-1 rounded-full">
            <span className="text-orange-600 dark:text-orange-400 text-sm font-bold">🔥 {stats.streak}</span>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4 pb-24 hide-scrollbar">
        {renderView()}
      </main>

      {/* Navigation - Bottom bar mobile style */}
      <nav className={`fixed bottom-0 left-0 right-0 max-w-lg mx-auto border-t px-2 py-3 flex justify-between z-20 shadow-lg transition-colors ${
        theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as View)}
              className={`flex flex-col items-center justify-center transition-all ${
                isActive 
                  ? 'text-indigo-500 scale-110' 
                  : (theme === 'dark' ? 'text-slate-500' : 'text-slate-400')
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-[10px] mt-1 font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default App;
