
import React, { useState } from 'react';
import { Brain, Loader2, Check, X, Trophy } from 'lucide-react';
import { generateQuiz } from '../services/geminiService.ts';
import { QuizQuestion, Quiz } from '../types.ts';

interface QuizViewProps {
  onQuizComplete: (quiz: Quiz) => void;
}

const QuizView: React.FC<QuizViewProps> = ({ onQuizComplete }) => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleStart = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const q = await generateQuiz(topic);
      setQuestions(q);
      setCurrentIndex(0);
      setScore(0);
      setShowResult(false);
      setIsAnswered(false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (option: string) => {
    if (isAnswered) return;
    setSelectedAnswer(option);
    setIsAnswered(true);
    if (option === questions[currentIndex].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsAnswered(false);
      setSelectedAnswer(null);
    } else {
      const finalQuiz: Quiz = {
        id: Date.now().toString(),
        topic,
        questions,
        score,
        total: questions.length,
        date: new Date().toISOString(),
      };
      onQuizComplete(finalQuiz);
      setShowResult(true);
    }
  };

  if (showResult) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center animate-in zoom-in-95 duration-300">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-800 max-w-sm w-full transition-colors">
          <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-6 text-amber-500">
            <Trophy className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-black mb-2">Quiz Complete!</h2>
          <p className="text-slate-500 dark:text-slate-400 mb-6">Great job on testing your knowledge on {topic}.</p>
          <div className="text-5xl font-black text-indigo-600 dark:text-indigo-400 mb-8">
            {score} <span className="text-2xl text-slate-300 dark:text-slate-700 font-medium">/ {questions.length}</span>
          </div>
          <button 
            onClick={() => {
              setQuestions([]);
              setTopic('');
              setShowResult(false);
            }}
            className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 dark:shadow-none"
          >
            Try Another Topic
          </button>
        </div>
      </div>
    );
  }

  if (questions.length > 0) {
    const q = questions[currentIndex];
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center px-2">
          <span className="text-xs font-bold text-slate-400 dark:text-slate-500 tracking-widest uppercase">Question {currentIndex + 1} of {questions.length}</span>
          <div className="flex gap-1">
            {questions.map((_, i) => (
              <div key={i} className={`w-8 h-1 rounded-full ${i <= currentIndex ? 'bg-indigo-500' : 'bg-slate-200 dark:bg-slate-800'}`} />
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 min-h-[160px] flex items-center justify-center text-center transition-colors">
          <h3 className="text-xl font-bold leading-snug">{q.question}</h3>
        </div>

        <div className="space-y-3">
          {q.options.map((option, idx) => {
            let style = "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700";
            if (isAnswered) {
              if (option === q.correctAnswer) style = "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500 text-emerald-700 dark:text-emerald-400";
              else if (option === selectedAnswer) style = "bg-rose-50 dark:bg-rose-900/20 border-rose-500 text-rose-700 dark:text-rose-400";
              else style = "bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-900 opacity-50";
            }
            
            return (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={() => handleAnswer(option)}
                className={`w-full p-4 rounded-2xl border-2 text-left font-semibold transition-all flex justify-between items-center ${style}`}
              >
                <span>{option}</span>
                {isAnswered && option === q.correctAnswer && <Check className="w-5 h-5" />}
                {isAnswered && option === selectedAnswer && option !== q.correctAnswer && <X className="w-5 h-5" />}
              </button>
            );
          })}
        </div>

        {isAnswered && (
          <div className="animate-in fade-in slide-in-from-top-4">
            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl mb-4 border border-indigo-100 dark:border-indigo-900/30">
              <h4 className="text-xs font-black text-indigo-400 dark:text-indigo-300 uppercase mb-1">Explanation</h4>
              <p className="text-sm text-indigo-900 dark:text-indigo-300 leading-relaxed">{q.explanation}</p>
            </div>
            <button
              onClick={nextQuestion}
              className="w-full bg-slate-800 dark:bg-slate-100 text-white dark:text-slate-900 py-4 rounded-2xl font-bold"
            >
              {currentIndex === questions.length - 1 ? "Finish Quiz" : "Next Question"}
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="bg-indigo-100 dark:bg-indigo-900/30 p-6 rounded-full mb-6 transition-colors">
        <Brain className="w-12 h-12 text-indigo-600 dark:text-indigo-400" />
      </div>
      <h2 className="text-2xl font-black mb-2">Challenge Yourself</h2>
      <p className="text-slate-500 dark:text-slate-400 text-sm max-w-[240px] mb-8 leading-relaxed">
        Let AI generate a customized quiz to test your mastery.
      </p>

      <div className="w-full space-y-3">
        <input 
          type="text" 
          placeholder="Enter a topic (e.g. Mitochondria)"
          className="w-full p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-colors"
          value={topic}
          onChange={e => setTopic(e.target.value)}
        />
        <button
          onClick={handleStart}
          disabled={loading || !topic}
          className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin w-5 h-5" /> : "Generate Quiz"}
        </button>
      </div>
    </div>
  );
};

export default QuizView;
