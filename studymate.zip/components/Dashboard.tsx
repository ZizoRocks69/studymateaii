
import React from 'react';
import { 
  BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { Trophy, CheckCircle } from 'lucide-react';
import { Task, Quiz, UserStats, StudyLog } from '../types.ts';

interface DashboardProps {
  stats: UserStats;
  tasks: Task[];
  quizzes: Quiz[];
  theme?: 'light' | 'dark';
  studyLogs: StudyLog[];
}

const Dashboard: React.FC<DashboardProps> = ({ stats, tasks, quizzes, theme, studyLogs }) => {
  const completedTasks = tasks.filter(t => t.completed).length;
  
  const cardClass = `p-4 rounded-xl shadow-sm border transition-colors ${
    theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
  }`;

  return (
    <div className="space-y-6">
      {/* Welcome Card */}
      <section className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl p-6 text-white shadow-lg">
        <h2 className="text-2xl font-bold mb-1">
          {stats.streak > 0 ? "Welcome back, Scholar!" : "Welcome to StudyMate!"}
        </h2>
        <p className="text-indigo-100 text-sm mb-4">
          {stats.streak > 0 
            ? `You're on a ${stats.streak}-day streak. Keep it up!` 
            : "Start your first study session to begin your streak!"}
        </p>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/10 p-3 rounded-xl border border-white/20">
            <span className="block text-xs text-indigo-200">Total Hours</span>
            <span className="text-xl font-bold">{stats.totalStudyHours}h</span>
          </div>
          <div className="bg-white/10 p-3 rounded-xl border border-white/20">
            <span className="block text-xs text-indigo-200">Topics Mastered</span>
            <span className="text-xl font-bold">{stats.completedTopics}</span>
          </div>
        </div>
      </section>

      {/* Progress Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className={`${cardClass} flex flex-col items-center`}>
          <div className={`p-3 rounded-full mb-3 ${theme === 'dark' ? 'bg-green-900/30 text-green-400' : 'bg-green-50 text-green-600'}`}>
            <CheckCircle className="w-6 h-6" />
          </div>
          <span className="text-2xl font-bold">{completedTasks}</span>
          <span className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>Tasks Completed</span>
        </div>
        <div className={`${cardClass} flex flex-col items-center`}>
          <div className={`p-3 rounded-full mb-3 ${theme === 'dark' ? 'bg-amber-900/30 text-amber-400' : 'bg-amber-50 text-amber-600'}`}>
            <Trophy className="w-6 h-6" />
          </div>
          <span className="text-2xl font-bold">{stats.totalQuizzes}</span>
          <span className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>Quizzes Taken</span>
        </div>
      </div>

      {/* Chart Section */}
      <section className={cardClass}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold">Study Activity</h3>
          <span className={`text-xs ${theme === 'dark' ? 'text-slate-500' : 'text-slate-400'}`}>Past 7 Days</span>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={studyLogs}>
              <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: theme === 'dark' ? '#64748b' : '#94a3b8'}} />
              <Tooltip 
                cursor={{fill: theme === 'dark' ? '#1e293b' : '#f1f5f9'}}
                contentStyle={{
                  borderRadius: '8px', 
                  border: 'none', 
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                  color: theme === 'dark' ? '#f1f5f9' : '#1e293b'
                }}
              />
              <Bar dataKey="hours" radius={[4, 4, 0, 0]}>
                {studyLogs.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === studyLogs.length - 1 ? '#6366f1' : (theme === 'dark' ? '#334155' : '#c7d2fe')} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Recent Quizzes */}
      <section className={cardClass}>
        <h3 className="font-bold mb-4">Recent Quizzes</h3>
        {quizzes.length === 0 ? (
          <p className="text-slate-500 text-sm italic py-4 text-center">No quizzes completed yet.</p>
        ) : (
          <div className="space-y-3">
            {quizzes.slice(0, 3).map((q) => (
              <div key={q.id} className={`flex justify-between items-center p-3 rounded-lg ${
                theme === 'dark' ? 'bg-slate-800/50' : 'bg-slate-50'
              }`}>
                <div>
                  <h4 className="text-sm font-semibold">{q.topic}</h4>
                  <span className="text-[10px] text-slate-500">{new Date(q.date).toLocaleDateString()}</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-indigo-500">
                    {q.score}/{q.total}
                  </span>
                  <div className={`w-16 h-1.5 rounded-full mt-1 ${theme === 'dark' ? 'bg-slate-700' : 'bg-slate-200'}`}>
                    <div 
                      className="h-full bg-indigo-500 rounded-full" 
                      style={{ width: `${((q.score || 0) / (q.total || 1)) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default Dashboard;
