
import React, { useState } from 'react';
import { Trophy, Loader2, Lightbulb, Share2, Clipboard } from 'lucide-react';
import { generateIdeas } from '../services/geminiService.ts';

const IdeaGenerator: React.FC = () => {
  const [keywords, setKeywords] = useState('');
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState<string[]>([]);

  const handleGenerate = async () => {
    if (!keywords) return;
    setLoading(true);
    try {
      const result = await generateIdeas(keywords);
      setIdeas(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-amber-50 dark:bg-amber-950/20 p-6 rounded-2xl border border-amber-100 dark:border-amber-900/30 transition-colors">
        <h2 className="text-xl font-bold text-amber-900 dark:text-amber-300 flex items-center gap-2 mb-2">
          <Lightbulb className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          Idea Spark
        </h2>
        <p className="text-amber-800/60 dark:text-amber-400/60 text-sm mb-6 leading-relaxed">
          Stuck on an essay or project? Enter some keywords and let AI spark your next big idea.
        </p>

        <div className="flex flex-col gap-3">
          <input 
            type="text" 
            placeholder="e.g. Sustainable energy, Ancient Rome..."
            className="w-full p-4 bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/30 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-colors"
            value={keywords}
            onChange={e => setKeywords(e.target.value)}
          />
          <button
            onClick={handleGenerate}
            disabled={loading || !keywords}
            className="bg-amber-600 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 hover:bg-amber-700 transition"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Ignite Ideas"}
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {ideas.map((idea, idx) => (
          <div key={idx} className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 group hover:border-amber-200 dark:hover:border-amber-900/50 transition-all duration-300">
            <div className="flex justify-between items-start mb-3">
              <div className="bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 p-2 rounded-lg">
                <Trophy className="w-4 h-4" />
              </div>
              <button 
                onClick={() => copyToClipboard(idea)}
                className="text-slate-300 dark:text-slate-600 hover:text-slate-500 dark:hover:text-slate-400 transition-colors"
              >
                <Clipboard className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
              {idea}
            </p>
          </div>
        ))}
      </div>
      
      {ideas.length === 0 && !loading && (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <Lightbulb className="w-12 h-12 mb-2 opacity-10" />
          <p className="text-sm italic">Enter keywords above to see the magic.</p>
        </div>
      )}
    </div>
  );
};

export default IdeaGenerator;
