
import React, { useState } from 'react';
import { Sparkles, Loader2, Book, Clock, ArrowRight } from 'lucide-react';
import { generateStudyPlan } from '../services/geminiService.ts';
import { StudyPlan } from '../types.ts';

const AIPlanner: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<StudyPlan | null>(null);

  const handleGenerate = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const result = await generateStudyPlan(topic);
      setPlan(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-indigo-50 dark:bg-indigo-950/20 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-900/30">
        <h2 className="text-xl font-bold text-indigo-900 dark:text-indigo-300 flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          AI Study Guide
        </h2>
        <p className="text-indigo-700/70 dark:text-indigo-400/60 text-sm mb-6 leading-relaxed">
          Enter a topic you want to master, and our AI will create a personalized learning journey for you.
        </p>

        <div className="flex flex-col gap-3">
          <input 
            type="text" 
            placeholder="e.g., Quantum Physics, Python Basics..."
            className="w-full p-4 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-900/30 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm transition-colors"
            value={topic}
            onChange={e => setTopic(e.target.value)}
          />
          <button
            onClick={handleGenerate}
            disabled={loading || !topic}
            className="bg-indigo-600 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 hover:bg-indigo-700 transition"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>Generate Plan <ArrowRight className="w-4 h-4" /></>
            )}
          </button>
        </div>
      </div>

      {plan && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <section className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
            <h3 className="text-lg font-bold mb-3">Topic Summary</h3>
            <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed whitespace-pre-line">
              {plan.summary}
            </p>
          </section>

          <h3 className="text-lg font-bold px-2 mt-6">Learning Path</h3>
          <div className="space-y-4 relative ml-4">
            <div className="absolute left-[-1rem] top-4 bottom-4 w-0.5 bg-indigo-100 dark:bg-indigo-900/30"></div>
            {plan.plan.map((step, idx) => (
              <div key={idx} className="relative bg-white dark:bg-slate-900 p-5 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
                <div className="absolute left-[-1.5rem] top-6 w-4 h-4 rounded-full bg-indigo-500 border-4 border-slate-50 dark:border-slate-950"></div>
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold">{step.phase}</h4>
                  <span className="text-[10px] bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {step.duration}
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">{step.description}</p>
                <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 w-fit px-3 py-1 rounded-full">
                  <Book className="w-3 h-3" />
                  {step.technique}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AIPlanner;
