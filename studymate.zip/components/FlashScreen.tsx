
import React from 'react';
import { BookOpen } from 'lucide-react';

interface FlashScreenProps {
  theme?: 'light' | 'dark';
}

const FlashScreen: React.FC<FlashScreenProps> = ({ theme }) => {
  return (
    <div className={`fixed inset-0 flex flex-col items-center justify-center z-50 transition-colors duration-1000 ${
      theme === 'dark' ? 'bg-slate-950' : 'bg-indigo-600'
    }`}>
      <div className="animate-bounce mb-8">
        <div className="bg-white p-6 rounded-3xl shadow-2xl">
          <BookOpen className="text-indigo-600 w-16 h-16" />
        </div>
      </div>
      <h1 className="text-4xl font-black text-white tracking-tight mb-2">StudyMate</h1>
      <p className="text-indigo-100 font-medium opacity-80 mb-12">Learn Smarter, Not Harder</p>
      
      <div className="w-48 h-1.5 bg-indigo-400/30 rounded-full overflow-hidden">
        <div className="h-full bg-white animate-[progress_2s_ease-in-out_infinite] w-full origin-left"></div>
      </div>

      <style>{`
        @keyframes progress {
          0% { transform: scaleX(0); }
          100% { transform: scaleX(1); }
        }
      `}</style>
    </div>
  );
};

export default FlashScreen;
