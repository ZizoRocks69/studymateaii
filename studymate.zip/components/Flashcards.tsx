
import React, { useState } from 'react';
import { Plus, Check, RotateCw, Trash2, Brain } from 'lucide-react';
import { Flashcard } from '../types.ts';

interface FlashcardsProps {
  cards: Flashcard[];
  setCards: React.Dispatch<React.SetStateAction<Flashcard[]>>;
}

const Flashcards: React.FC<FlashcardsProps> = ({ cards, setCards }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newCard, setNewCard] = useState({ front: '', back: '' });
  const [reviewMode, setReviewMode] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const addCard = () => {
    if (!newCard.front || !newCard.back) return;
    const card: Flashcard = {
      id: Date.now().toString(),
      ...newCard,
      status: 'new'
    };
    setCards([card, ...cards]);
    setNewCard({ front: '', back: '' });
    setIsAdding(false);
  };

  const deleteCard = (id: string) => {
    setCards(cards.filter(c => c.id !== id));
  };

  const markLearned = (id: string) => {
    setCards(cards.map(c => c.id === id ? { ...c, status: 'learned' } : c));
    if (reviewMode) nextCard();
  };

  const nextCard = () => {
    setIsFlipped(false);
    if (currentIdx < cards.length - 1) {
      setTimeout(() => setCurrentIdx(currentIdx + 1), 200);
    } else {
      setReviewMode(false);
    }
  };

  if (reviewMode && cards.length > 0) {
    const card = cards[currentIdx];
    return (
      <div className="space-y-8 py-8 h-[calc(100vh-14rem)] flex flex-col items-center justify-center">
        <div className="w-full flex justify-between items-center mb-4 px-4">
          <span className="text-xs font-bold text-slate-400 dark:text-slate-500">CARD {currentIdx + 1} / {cards.length}</span>
          <button onClick={() => setReviewMode(false)} className="text-sm font-bold text-rose-500">Exit</button>
        </div>

        <div 
          onClick={() => setIsFlipped(!isFlipped)}
          className="w-full aspect-[4/5] perspective-1000 cursor-pointer relative"
        >
          <div className={`relative w-full h-full transition-transform duration-500 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
            {/* Front */}
            <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-3xl shadow-xl p-8 flex flex-col items-center justify-center text-center transition-colors">
              <span className="absolute top-6 left-6 text-[10px] font-black text-indigo-400 dark:text-indigo-300 uppercase tracking-widest">Question</span>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 leading-tight">{card.front}</h3>
              <div className="mt-12 text-slate-300 dark:text-slate-600 flex items-center gap-2 text-xs font-bold">
                <RotateCw className="w-3 h-3" /> Tap to flip
              </div>
            </div>
            {/* Back */}
            <div className="absolute inset-0 backface-hidden bg-indigo-600 rounded-3xl shadow-xl p-8 flex flex-col items-center justify-center text-center rotate-y-180">
              <span className="absolute top-6 left-6 text-[10px] font-black text-indigo-300 uppercase tracking-widest">Answer</span>
              <p className="text-xl font-medium text-white leading-relaxed">{card.back}</p>
            </div>
          </div>
        </div>

        {isFlipped && (
          <div className="flex gap-4 w-full px-4 animate-in fade-in slide-in-from-bottom-4">
            <button 
              onClick={nextCard}
              className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-4 rounded-2xl font-bold hover:bg-slate-200 transition-colors"
            >
              Needs Review
            </button>
            <button 
              onClick={() => markLearned(card.id)}
              className="flex-1 bg-indigo-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-100 dark:shadow-none"
            >
              <Check className="w-5 h-5" /> I Learned This
            </button>
          </div>
        )}

        <style>{`
          .perspective-1000 { perspective: 1000px; }
          .transform-style-3d { transform-style: preserve-3d; }
          .backface-hidden { backface-visibility: hidden; }
          .rotate-y-180 { transform: rotateY(180deg); }
        `}</style>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Flashcards</h2>
        <div className="flex gap-2">
          {cards.length > 0 && (
            <button 
              onClick={() => { setReviewMode(true); setCurrentIdx(0); setIsFlipped(false); }}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md hover:bg-indigo-700 flex items-center gap-2 transition-colors"
            >
              <Brain className="w-4 h-4" /> Study Now
            </button>
          )}
          <button 
            onClick={() => setIsAdding(!isAdding)}
            className="bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/30 p-2 rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {isAdding && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-900/30 shadow-md space-y-4 animate-in slide-in-from-top-4 transition-colors">
          <textarea 
            placeholder="Front (Question/Term)"
            rows={2}
            className="w-full p-3 bg-slate-50 dark:bg-slate-950 border dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm transition-colors"
            value={newCard.front}
            onChange={e => setNewCard({...newCard, front: e.target.value})}
          />
          <textarea 
            placeholder="Back (Answer/Definition)"
            rows={2}
            className="w-full p-3 bg-slate-50 dark:bg-slate-950 border dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm transition-colors"
            value={newCard.back}
            onChange={e => setNewCard({...newCard, back: e.target.value})}
          />
          <button 
            onClick={addCard}
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold shadow-lg"
          >
            Save Card
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {cards.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <Plus className="w-12 h-12 mb-2 opacity-10" />
            <p className="text-sm">Create your first flashcard to start learning.</p>
          </div>
        ) : (
          cards.map(card => (
            <div key={card.id} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm flex items-start gap-4 transition-colors">
              <div className="flex-1">
                <p className="font-bold text-sm mb-1">{card.front}</p>
                <p className="text-slate-500 dark:text-slate-400 text-xs line-clamp-2">{card.back}</p>
                <div className="mt-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    card.status === 'learned' 
                      ? 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400' 
                      : 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400'
                  }`}>
                    {card.status}
                  </span>
                </div>
              </div>
              <button 
                onClick={() => deleteCard(card.id)}
                className="text-slate-200 dark:text-slate-700 hover:text-rose-500 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Flashcards;
