
import React, { useState } from 'react';
import { Plus, Trash2, CheckCircle, Circle, AlertCircle } from 'lucide-react';
import { Task, Priority } from '../types.ts';

interface PlannerProps {
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  onTaskToggle?: (updatedTasks: Task[], taskId: string) => void;
}

const Planner: React.FC<PlannerProps> = ({ tasks, setTasks, onTaskToggle }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    subject: '',
    priority: 'medium' as Priority,
    date: new Date().toISOString().split('T')[0]
  });

  const addTask = () => {
    if (!newTask.title) return;
    const task: Task = {
      id: Date.now().toString(),
      ...newTask,
      completed: false
    };
    setTasks([task, ...tasks]);
    setNewTask({ title: '', subject: '', priority: 'medium', date: new Date().toISOString().split('T')[0] });
    setIsAdding(false);
  };

  const toggleTask = (id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(updated);
    if (onTaskToggle) onTaskToggle(updated, id);
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const getPriorityColor = (p: Priority) => {
    switch (p) {
      case 'high': return 'bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400';
      case 'medium': return 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400';
      case 'low': return 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Study Planner</h2>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 text-white p-2 rounded-full shadow-md hover:bg-indigo-700 transition"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {isAdding && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl shadow-md border border-indigo-100 dark:border-indigo-900/30 space-y-3 animate-in slide-in-from-top-4 duration-300">
          <input 
            type="text" 
            placeholder="What are you studying?"
            className="w-full p-3 border dark:border-slate-800 dark:bg-slate-950 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-colors"
            value={newTask.title}
            onChange={e => setNewTask({...newTask, title: e.target.value})}
          />
          <div className="grid grid-cols-2 gap-3">
            <input 
              type="text" 
              placeholder="Subject"
              className="p-2 border dark:border-slate-800 dark:bg-slate-950 rounded-lg text-sm transition-colors"
              value={newTask.subject}
              onChange={e => setNewTask({...newTask, subject: e.target.value})}
            />
            <input 
              type="date" 
              className="p-2 border dark:border-slate-800 dark:bg-slate-950 rounded-lg text-sm transition-colors"
              value={newTask.date}
              onChange={e => setNewTask({...newTask, date: e.target.value})}
            />
          </div>
          <div className="flex gap-2">
            {(['low', 'medium', 'high'] as Priority[]).map(p => (
              <button
                key={p}
                onClick={() => setNewTask({...newTask, priority: p})}
                className={`flex-1 py-1 px-3 rounded-full text-xs font-semibold capitalize border transition-colors ${
                  newTask.priority === p 
                    ? 'bg-indigo-600 text-white border-indigo-600' 
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
          <button 
            onClick={addTask}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold shadow-lg hover:bg-indigo-700 mt-2"
          >
            Add Session
          </button>
        </div>
      )}

      <div className="space-y-3">
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <AlertCircle className="w-12 h-12 mb-2 opacity-20" />
            <p className="text-sm">No study sessions planned.</p>
          </div>
        ) : (
          tasks.map(task => (
            <div 
              key={task.id}
              className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${
                task.completed 
                  ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-100 dark:border-slate-800 opacity-60' 
                  : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 shadow-sm'
              }`}
            >
              <button onClick={() => toggleTask(task.id)}>
                {task.completed ? (
                  <CheckCircle className="w-6 h-6 text-green-500 fill-green-50 dark:fill-green-950" />
                ) : (
                  <Circle className="w-6 h-6 text-slate-300 dark:text-slate-600" />
                )}
              </button>
              <div className="flex-1 min-w-0">
                <h4 className={`font-semibold truncate ${task.completed ? 'text-slate-400 line-through' : ''}`}>
                  {task.title}
                </h4>
                <div className="flex gap-2 mt-1">
                  <span className="text-[10px] bg-indigo-50 dark:bg-indigo-900/30 text-indigo-500 dark:text-indigo-300 px-2 py-0.5 rounded-full font-medium">
                    {task.subject}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium capitalize ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
              </div>
              <button 
                onClick={() => deleteTask(task.id)}
                className="text-slate-300 dark:text-slate-600 hover:text-rose-500 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Planner;
